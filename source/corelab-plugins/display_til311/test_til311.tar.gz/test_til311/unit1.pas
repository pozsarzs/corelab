unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  display_til311;
type
  { TForm1 }
  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Panel1: TPanel;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormPaint(Sender: TObject);
  private
    TIL311: TDisplayTIL311;
  end;
var
  Form1: TForm1;
  value: byte = 0;
  x: byte = 0;
  y: byte = 0;

implementation

{$R *.lfm}

procedure TForm1.FormCreate(Sender: TObject);
begin
  TIL311 := TDisplayTIL311.Create;
  TIL311.SetValue(0);
  TIL311.SetLeftDot(True);
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  if value < 15 then Inc(value);
  TIL311.SetValue(value);
  TIL311.RenderTo(Panel1.Canvas, x, y);
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  if value > 0 then Dec(value);
  TIL311.SetValue(value);
  TIL311.RenderTo(Panel1.Canvas, x, y);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  TIL311.Free;
end;

procedure TForm1.FormPaint(Sender: TObject);
begin
  TIL311.RenderTo(Panel1.Canvas, x, y);
end;

end.
