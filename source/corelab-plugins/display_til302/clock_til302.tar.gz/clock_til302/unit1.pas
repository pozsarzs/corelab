{ +--------------------------------------------------------------------------+ }
{ | CoreLAB v0.1 - Modular Processor Simulation Framework                    | }
{ | Copyright (C) 2026 Pozsar Zsolt <pozsarzs@gmail.com>                     | }
{ | unit1.pas                                                                | }
{ | Main form                                                                | }
{ +--------------------------------------------------------------------------+ }
{ This program is free software: you can redistribute it and/or modify it
  under the terms of the European Union Public License 1.2 version.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE. }

unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls,
  display_TIL302;
type
  { TForm1 }
  TForm1 = class(TForm)
    Panel1: TPanel;
    Timer1: TTimer;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormPaint(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
  private
    Displays: array[0..5] of TDisplayTIL302;
  end;
var
  Form1: TForm1;
  StartX: Integer = 1;
  StartY: Integer = 1;
  Spacing: Integer = 111;

{$I bcd7seg_7447.pas}

implementation

{$R *.lfm}

procedure TForm1.FormCreate(Sender: TObject);
var
  i: Integer;
begin
  for i := 0 to 5 do
  begin
    Displays[i] := TDisplayTIL302.Create;
    Displays[i].SetSegments(BCD7seg_7447[0]);
    Displays[i].SetLeftDot(False);
    Displays[i].SetRightDot(False);
  end;
  Displays[1].SetRightDot(True);
  Displays[3].SetRightDot(True);
end;

procedure TForm1.Timer1Timer(Sender: TObject);
var
  H, M, S, MS: Word;
begin
  DecodeTime(Time, H, M, S, MS);
  writeln(H, ' ', H div 10);
  Displays[0].SetSegments(BCD7seg_7447[H div 10]);
  Displays[1].SetSegments(BCD7seg_7447[H mod 10]);
  Displays[2].SetSegments(BCD7seg_7447[M div 10]);
  Displays[3].SetSegments(BCD7seg_7447[M mod 10]);
  Displays[4].SetSegments(BCD7seg_7447[S div 10]);
  Displays[5].SetSegments(BCD7seg_7447[S mod 10]);
  if odd(S) then
  begin
    Displays[1].SetRightDot(False);
    Displays[3].SetRightDot(False);
  end else
  begin
    Displays[1].SetRightDot(True);
    Displays[3].SetRightDot(True);
  end;
  FormPaint(Sender);
end;

procedure TForm1.FormPaint(Sender: TObject);
var
  i, posX: Integer;
begin
  posX := StartX;
  for i := 0 to 5 do
  begin
    Displays[i].RenderTo(Panel1.Canvas, posX, StartY);
    posX := posX + Spacing;
  end;
end;

procedure TForm1.FormDestroy(Sender: TObject);
var
  i: Integer;
begin
  for i := 0 to 5 do Displays[i].Free;
end;

end.
