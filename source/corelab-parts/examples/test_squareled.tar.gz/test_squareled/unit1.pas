{ +--------------------------------------------------------------------------+ }
{ | CoreLAB v0.1 - Modular Processor Simulation Framework                    | }
{ | Copyright (C) 2026 Pozsar Zsolt <pozsarzs@gmail.com>                     | }
{ | unit1.pas                                                                | }
{ | Main form                                                                | }
{ +--------------------------------------------------------------------------+ }
{ This program is free software: you can redistribute it and/or modify it
  under the terms of the European Union Public License 1.2 version.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE. }

unit unit1;
{$MODE OBJFPC}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  core_led, led_square;
type
  { TForm1 }
  TForm1 = class(TForm)
    CheckBox1: TCheckBox;
    PaintBox1: TPaintBox;
    RadioGroup1: TRadioGroup;
    Timer1: TTimer;
    procedure CheckBox1Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure PaintBox1Paint(Sender: TObject);
    procedure RadioGroup1Click(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
  private
    FLED: TLEDSquare;
  public
  end;
var
  Form1: TForm1;

implementation

{$R *.lfm}

procedure TForm1.FormCreate(Sender: TObject);
begin
  FLED := TLEDSquare.Create;
  FLED.Color := RETRO_COLORS[clRetroRed];
  FLED.BGColor := clBackground;
  FLED.IsOn := False;
  CheckBox1.checked := true;
  Timer1.Enabled:=CheckBox1.checked;
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  FLED.Free;
end;

procedure TForm1.CheckBox1Change(Sender: TObject);
begin
  Timer1.Enabled := CheckBox1.checked;
end;

procedure TForm1.PaintBox1Paint(Sender: TObject);
begin
  if Assigned(FLED) then FLED.RenderTo(PaintBox1.Canvas, 0, 0);
end;

procedure TForm1.RadioGroup1Click(Sender: TObject);
begin
  case RadioGroup1.ItemIndex of
    0: FLED.Color := RETRO_COLORS[clRetroRed];
    1: FLED.Color := RETRO_COLORS[clRetroGreen];
    2: FLED.Color := RETRO_COLORS[clRetroYellow];
  end;
  PaintBox1.Invalidate;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
begin
  FLED.IsOn := not FLED.IsOn;
  PaintBox1.Invalidate;
  Timer1.Enabled := true;
end;

end.
