{ +--------------------------------------------------------------------------+ }
{ | CoreLAB v0.1 - Modular Processor Simulation Framework                    | }
{ | Copyright (C) 2026 Pozsar Zsolt <pozsarzs@gmail.com>                     | }
{ | unit1.pas                                                                | }
{ | Main form                                                                | }
{ +--------------------------------------------------------------------------+ }
{ This program is free software: you can redistribute it and/or modify it
  under the terms of the European Union Public License 1.2 version.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE. }

unit Unit1;
{$mode objfpc}{$H+}
interface
uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  display_til302;
type
  { TForm1 }
  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    CheckBox1: TCheckBox;
    Panel1: TPanel;
    RadioGroup1: TRadioGroup;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure CheckBox1Change(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormPaint(Sender: TObject);
    procedure RadioGroup1SelectionChanged(Sender: TObject);
  private
    TIL302: TDisplayTIL302;
  end;
var
  Form1: TForm1;
  value: byte = 0;
  x: byte = 0;
  y: byte = 0;

{$I bcd7seg_7447.pas}

implementation

{$R *.lfm}

procedure TForm1.FormCreate(Sender: TObject);
begin
  TIL302 := TDisplayTIL302.Create;
  TIL302.SetSegments(BCD7seg_7447[0]);
  TIL302.SetLeftDot(True);
end;

procedure TForm1.Button1Click(Sender: TObject);
begin
  if value > 0 then Dec(value);
  TIL302.SetSegments(BCD7seg_7447[value]);
  TIL302.RenderTo(Panel1.Canvas, x, y);
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  if value < 15 then Inc(value);
  TIL302.SetSegments(BCD7seg_7447[value]);
  TIL302.RenderTo(Panel1.Canvas, x, y);
end;

procedure TForm1.CheckBox1Change(Sender: TObject);
begin
  TIL302.SetBlank(CheckBox1.Checked);
  TIL302.RenderTo(Panel1.Canvas, x, y);
end;

procedure TForm1.FormPaint(Sender: TObject);
begin
  TIL302.RenderTo(Panel1.Canvas, x, y);
end;

procedure TForm1.RadioGroup1SelectionChanged(Sender: TObject);
begin
  with TIL302 do
    if RadioGroup1.ItemIndex = 0
    then begin SetLeftDot(true); SetRightDot(false); end
    else begin SetLeftDot(false); SetRightDot(true); end;
  TIL302.RenderTo(Panel1.Canvas, x, y);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  TIL302.Free;
end;

end.
