{ +--------------------------------------------------------------------------+ }
{ | CoreLAB v0.1 - Modular Processor Simulation Framework                    | }
{ | Copyright (C) 2026 Pozsar Zsolt <pozsarzs@gmail.com>                     | }
{ | commandregistry.pas                                                      | }
{ | Command registry class                                                   | }
{ +--------------------------------------------------------------------------+ }
{ This program is free software: you can redistribute it and/or modify it
  under the terms of the European Union Public License 1.2 version.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
  FOR A PARTICULAR PURPOSE. }

unit commandregistry;
{$MODE OBJFPC}{$H+}
interface
uses
  Generics.Collections, SysUtils, command;
type
  // Dictionary with <command name, command object> elements
  TCommandDict = specialize TDictionary<string, TCommand>;
  // Command registry class
  TCommandRegistry = class
  protected
    FCommands: TCommandDict;                           // Dictionary of commands
  public
    constructor Create; virtual;
    destructor Destroy; override;
    function FindCommand(const AName: string): TCommand;
    procedure RegisterCommand(ACommand: TCommand); virtual;
    property Commands: TCommandDict read FCommands;
  end;

implementation

// CREATE TCOMMANDREGISTRY INSTANCE
constructor TCommandRegistry.Create;
begin
  inherited Create;
  FCommands := TCommandDict.Create;
end;

// DESTROY TCOMMANDREGISTRY INSTANCE
destructor TCommandRegistry.Destroy;
var
  Command: TCommand;
begin
  for Command in FCommands.Values do Command.Free;
  inherited Destroy;
end;

// TRY TO GET THE COMMAND FROM COMMAND NAME
function TCommandRegistry.FindCommand(const AName: string): TCommand;
begin
  if not FCommands.TryGetValue(LowerCase(AName), Result) then
    Result := nil; 
end;

// ADD COMMAND TO REGISTRY
procedure TCommandRegistry.RegisterCommand(ACommand: TCommand);
begin
  FCommands.Add(LowerCase(ACommand.Name), ACommand);
end;

begin
end.
